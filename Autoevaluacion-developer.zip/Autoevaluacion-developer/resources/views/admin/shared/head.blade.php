<!-- Bootstrap -->
<link href="{{ asset('gentella/vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{ asset('gentella/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
<!-- NProgress -->
<link href="{{ asset('gentella/vendors/nprogress/nprogress.css') }}" rel="stylesheet">
<!-- jQuery custom content scroller -->
<link href="{{ asset('gentella/vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css') }}"
      rel="stylesheet"/>
<!-- Styles for content-->
@stack('styles')
<!-- Custom Theme Style -->
<link href="{{ asset('gentella/build/css/custom.css') }}" rel="stylesheet"/>