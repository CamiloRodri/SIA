<!-- Modal Cancelar-->
<div class="modal fade" id="modal_mostrar_cancelar_peticion" tabindex="-1" role="dialog" aria-labelledby="modal_titulo">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal_titulo">¿Esta seguro?</h4>
            </div>
            <div class="modal-body">
                <h4>Si oprime el botón aceptar se perderán todos los datos que ha digitado en el formulario.</h4>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-info" data-dismiss="modal">Cancelar</button>
                <a class="btn btn-danger" href="#" id="cancelar_peticion" role="button">Aceptar</a>
            </div>
        </div>
    </div>
</div>
<!--FIN Modal Cancelar-->