<!-- jQuery -->
<script src="{{ asset('gentella/vendors/jquery/dist/jquery.min.js') }}"></script>
<!-- Bootstrap -->
<script src="{{ asset('gentella/vendors/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<!-- FastClick -->
<script src="{{ asset('gentella/vendors/fastclick/lib/fastclick.js') }}"></script>
<!-- NProgress -->
<script src="{{ asset('gentella/vendors/nprogress/nprogress.js') }}"></script>
<!-- jQuery custom content scroller -->
<script src="{{ asset('gentella/vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js') }}"></script>
<!-- Scripts for content -->
@stack('scripts')
<!-- Custom Theme Scripts -->
<script src="{{ asset('gentella/build/js/custom.js') }}"></script>
<script src="{{ asset('js/admin.js') }}"></script>


